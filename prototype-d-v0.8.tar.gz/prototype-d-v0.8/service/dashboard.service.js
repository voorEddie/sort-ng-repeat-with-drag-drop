(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .factory('DashboardService', DashboardService);

    DashboardService.$inject = [];

    function DashboardService() {

        return {
            cpObjAryWithTargetAttr: cpObjAryWithTargetAttr,
            findObjByAttrInObjAry: findObjByAttrInObjAry,
            getPeriodOptions: getPeriodOptions
        };

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /**
         * copy an Array of Objects with target attributes
         */
        function cpObjAryWithTargetAttr(objAry, targetAttr) {
            var result = [];
            if (objAry.length > 0 && targetAttr.length > 0) {
                objAry.forEach(function (obj) {
                    var temp = {};
                    targetAttr.forEach(function (attr) {
                        temp[attr] = obj[attr];
                    });
                    result.push(temp);
                });
            }
            return result;
        }

        /**
         * find the index of an Object in an Array of Objects which target attributes value is targetAttrValue
         */
        function findObjByAttrInObjAry(objAry, targetAttr, targetAttrValue) {
            for (var i = 0, l = objAry.length; i < l; i++) {
                if (objAry[i][targetAttr] === targetAttrValue) {
                    return i;
                }
            }
        }
        
        function getPeriodOptions() {
            return [
                {title: '15 MINUTES', value: '0.25'},
                {title: '1 HOUR', value: '1'},
                {title: '1 DAY', value: '24'},
                {title: '1 WEEK', value: '168'}
            ];
        }
    }
})();