(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .factory('DummyDataService', DummyDataService);

    DummyDataService.$inject = [];

    function DummyDataService() {
        return {
            apiGetNeAndResource: apiGetNeAndResource,
            apiGetDashboardConfig: apiGetDashboardConfig
        };

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function apiGetNeAndResource() {
            /**
             * Emulates a server response for apiGetNeAndResource
             * Each time this service is called, some randomized json data will return
             */
            return {
                ne: {
                    enb: 800 + randomOneToTen(),
                    cell: 800 + randomOneToTen()
                },
                status: {
                    server: 6 + randomOneToTen(),
                    cpu: 80 + randomOneToTen() + '%',
                    memory: 70 + randomOneToTen() + '%',
                    storage: 60 + randomOneToTen() + '%'
                }
            };

            function randomOneToTen() {
                return Math.floor(Math.random() * 10) + 1;
            }
        }

        function apiGetDashboardConfig() {
            /**
             * Emulates a server response for apiGetDashboardItem
             * This API response an array of items that dashboard needs rendering
             */
            return {
                layoutMode: 'layout1',
                item: [
                    {id: 'id_0', title: 'Item-A', subTitle: 'Item-A-DUMMY-SUB-TITLE', order: 5, visible: true},
                    {
                        id: 'id_1',
                        title: 'Item-B-DUMMY-TITLE WHICH IS REALLY REALLY LONG THAT IT CANNOT FIT WITH PATENT CONTAINER',
                        subTitle: 'Item-B-DUMMY-SUB-TITLE WHICH IS REALLY REALLY LONG THAT IT CANNOT FIT WITH PATENT CONTAINER',
                        order: 3,
                        visible: true
                    },
                    {id: 'id_2', title: 'Item-C', subTitle: 'Item-C-DUMMY-SUB-TITLE', order: 2, visible: false},
                    {id: 'id_3', title: 'Item-D', subTitle: 'Item-D-DUMMY-SUB-TITLE', order: 1, visible: true},
                    {id: 'id_4', title: 'Item-E', subTitle: 'Item-E-DUMMY-SUB-TITLE', order: 4, visible: false},
                    {id: 'id_5', title: 'Item-F', subTitle: 'Item-F-DUMMY-SUB-TITLE', order: 8, visible: true},
                    {id: 'id_6', title: 'Item-G', subTitle: 'Item-G-DUMMY-SUB-TITLE', order: 0, visible: true},
                    {id: 'id_7', title: 'Item-H', subTitle: 'Item-H-DUMMY-SUB-TITLE', order: 7, visible: true},
                    {id: 'id_8', title: 'Item-I', subTitle: 'Item-I-DUMMY-SUB-TITLE', order: 6, visible: true}
                ]
            }
        }
    }
})();