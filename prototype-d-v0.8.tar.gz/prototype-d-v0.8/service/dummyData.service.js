(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .factory('DummyDataService', DummyDataService);

    DummyDataService.$inject = [];

    function DummyDataService() {
        return {
            apiGetNeAndResource: apiGetNeAndResource,
            apiGetDashboardConfig: apiGetDashboardConfig,
            apiGetParam1: apiGetParam1,
            apiGetParam2: apiGetParam2,
            apiGetParam3: apiGetParam3,
            apiGetParam4: apiGetParam4
        };

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function apiGetNeAndResource() {
            /**
             * Emulates a server response for apiGetNeAndResource
             * Each time this service is called, some randomized json data will return
             */
            return {
                ne: {
                    enb: 800 + randomOneToTen(),
                    cell: 800 + randomOneToTen()
                },
                status: {
                    server: 6 + randomOneToTen(),
                    cpu: 80 + randomOneToTen() + '%',
                    memory: 70 + randomOneToTen() + '%',
                    storage: 60 + randomOneToTen() + '%'
                }
            };

            function randomOneToTen() {
                return Math.floor(Math.random() * 10) + 1;
            }
        }

        function apiGetDashboardConfig() {
            /**
             * Emulates a server response for apiGetDashboardItem
             * This API response an array of items that dashboard needs rendering
             */
            return {
                layoutMode: 'layout1',
                item: [
                    {
                        id: 'id_0',
                        period: '0.25',
                        title: 'Item-A',
                        subTitle: 'Item-A-DUMMY-SUB-TITLE',
                        order: 5,
                        visible: true,
                        params: [
                            {param1: ['param1-2-3']},
                            {param2: ['param2-4-1']},
                            {param3: ['param3-1-1']},
                            {param4: ['param4-5-5']}
                        ]
                    },
                    {
                        id: 'id_1',
                        period: '24',
                        title: 'Item-B-DUMMY-TITLE WHICH IS REALLY REALLY LONG THAT IT CANNOT FIT WITH PATENT CONTAINER',
                        subTitle: 'Item-B-DUMMY-SUB-TITLE WHICH IS REALLY REALLY LONG THAT IT CANNOT FIT WITH PATENT CONTAINER',
                        order: 3,
                        visible: true, params: [
                        {param1: ['param1-4-2']},
                        {param2: ['param2-4-2']},
                        {param3: ['param3-1-2']},
                        {param4: ['param4-5-4']}
                    ]
                    },
                    {
                        id: 'id_2',
                        period: '24',
                        title: 'Item-C',
                        subTitle: 'Item-C-DUMMY-SUB-TITLE',
                        order: 2,
                        visible: false,
                        params: [
                            {param1: ['param1-2-1']},
                            {param2: ['param2-4-3']},
                            {param3: ['param3-1-3']},
                            {param4: ['param4-5-3']}
                        ]
                    },
                    {
                        id: 'id_3',
                        period: '1',
                        title: 'Item-D',
                        subTitle: 'Item-D-DUMMY-SUB-TITLE',
                        order: 1,
                        visible: true,
                        params: [
                            {param1: ['param1-3-3']},
                            {param2: ['param2-2-1']},
                            {param3: ['param3-1-4']},
                            {param4: ['param4-5-2']}
                        ]
                    },
                    {
                        id: 'id_4',
                        period: '0.25',
                        title: 'Item-E',
                        subTitle: 'Item-E-DUMMY-SUB-TITLE',
                        order: 4,
                        visible: false,
                        params: [
                            {param1: ['param1-1-1']},
                            {param2: ['param2-2-2']},
                            {param3: ['param3-2-5']},
                            {param4: ['param4-4-3']}
                        ]
                    },
                    {
                        id: 'id_5',
                        period: '168',
                        title: 'Item-F',
                        subTitle: 'Item-F-DUMMY-SUB-TITLE',
                        order: 8,
                        visible: true,
                        params: [
                            {param1: ['param1-3-1']},
                            {param2: ['param2-3-1']},
                            {param3: ['param3-2-4']},
                            {param4: ['param4-4-4']}
                        ]
                    },
                    {
                        id: 'id_6',
                        period: '0.25',
                        title: 'Item-G',
                        subTitle: 'Item-G-DUMMY-SUB-TITLE',
                        order: 0,
                        visible: true,
                        params: [
                            {param1: ['param1-2-1']},
                            {param2: ['param2-3-2']},
                            {param3: ['param3-2-3']},
                            {param4: ['param4-3-3']}
                        ]
                    },
                    {
                        id: 'id_7',
                        period: '1',
                        title: 'Item-H',
                        subTitle: 'Item-H-DUMMY-SUB-TITLE',
                        order: 7,
                        visible: true,
                        params: [
                            {param1: ['param1-3-2']},
                            {param2: ['param2-5-1']},
                            {param3: ['param3-3-4']},
                            {param4: ['param4-3-1']}
                        ]
                    },
                    {
                        id: 'id_8',
                        period: '24',
                        title: 'Item-I',
                        subTitle: 'Item-I-DUMMY-SUB-TITLE',
                        order: 6,
                        visible: true,
                        params: [
                            {param1: ['param1-4-1']},
                            {param2: ['param2-5-3']},
                            {param3: ['param3-4-5']},
                            {param4: ['param4-2-3']}
                        ]
                    }
                ]
            }
        }

        function apiGetParam1() {
            return {
                node: 'param1', chlNode: [
                    {node: 'param1-1', chlNode: [
                        {node: 'param1-1-1', chlNode: []},
                        {node: 'param1-1-2', chlNode: []},
                        {node: 'param1-1-3', chlNode: []},
                        {node: 'param1-1-4', chlNode: []},
                        {node: 'param1-1-5', chlNode: []}
                    ]},
                    {node: 'param1-2', chlNode: [
                        {node: 'param1-2-1', chlNode: []},
                        {node: 'param1-2-2', chlNode: []},
                        {node: 'param1-2-3', chlNode: []},
                        {node: 'param1-2-4', chlNode: []},
                        {node: 'param1-2-5', chlNode: []}
                    ]},
                    {node: 'param1-3', chlNode: [
                        {node: 'param1-3-1', chlNode: []},
                        {node: 'param1-3-2', chlNode: []},
                        {node: 'param1-3-3', chlNode: []},
                        {node: 'param1-3-4', chlNode: []},
                        {node: 'param1-3-5', chlNode: []}
                    ]},
                    {node: 'param1-4', chlNode: [
                        {node: 'param1-4-1', chlNode: []},
                        {node: 'param1-4-2', chlNode: []},
                        {node: 'param1-4-3', chlNode: []},
                        {node: 'param1-4-4', chlNode: []},
                        {node: 'param1-4-5', chlNode: []}
                    ]},
                    {node: 'param1-5', chlNode: [
                        {node: 'param1-5-1', chlNode: []},
                        {node: 'param1-5-2', chlNode: []},
                        {node: 'param1-5-3', chlNode: []},
                        {node: 'param1-5-4', chlNode: []},
                        {node: 'param1-5-5', chlNode: []}
                    ]}
                ]
            };
        }

        function apiGetParam2() {
            return {
                node: 'param2', chlNode: [
                    {node: 'param2-1', chlNode: [
                        {node: 'param2-1-1', chlNode: []},
                        {node: 'param2-1-2', chlNode: []},
                        {node: 'param2-1-3', chlNode: []},
                        {node: 'param2-1-4', chlNode: []},
                        {node: 'param2-1-5', chlNode: []}
                    ]},
                    {node: 'param2-2', chlNode: [
                        {node: 'param2-2-1', chlNode: []},
                        {node: 'param2-2-2', chlNode: []},
                        {node: 'param2-2-3', chlNode: []},
                        {node: 'param2-2-4', chlNode: []},
                        {node: 'param2-2-5', chlNode: []}
                    ]},
                    {node: 'param2-3', chlNode: [
                        {node: 'param2-3-1', chlNode: []},
                        {node: 'param2-3-2', chlNode: []},
                        {node: 'param2-3-3', chlNode: []},
                        {node: 'param2-3-4', chlNode: []},
                        {node: 'param2-3-5', chlNode: []}
                    ]},
                    {node: 'param2-4', chlNode: [
                        {node: 'param2-4-1', chlNode: []},
                        {node: 'param2-4-2', chlNode: []},
                        {node: 'param2-4-3', chlNode: []},
                        {node: 'param2-4-4', chlNode: []},
                        {node: 'param2-4-5', chlNode: []}
                    ]},
                    {node: 'param2-5', chlNode: [
                        {node: 'param2-5-1', chlNode: []},
                        {node: 'param2-5-2', chlNode: []},
                        {node: 'param2-5-3', chlNode: []},
                        {node: 'param2-5-4', chlNode: []},
                        {node: 'param2-5-5', chlNode: []}
                    ]}
                ]
            };
        }

        function apiGetParam3() {
            return {
                node: 'param3', chlNode: [
                    {node: 'param3-1', chlNode: [
                        {node: 'param3-1-1', chlNode: []},
                        {node: 'param3-1-2', chlNode: []},
                        {node: 'param3-1-3', chlNode: []},
                        {node: 'param3-1-4', chlNode: []},
                        {node: 'param3-1-5', chlNode: []}
                    ]},
                    {node: 'param3-2', chlNode: [
                        {node: 'param3-2-1', chlNode: []},
                        {node: 'param3-2-2', chlNode: []},
                        {node: 'param3-2-3', chlNode: []},
                        {node: 'param3-2-4', chlNode: []},
                        {node: 'param3-2-5', chlNode: []}
                    ]},
                    {node: 'param3-3', chlNode: [
                        {node: 'param3-3-1', chlNode: []},
                        {node: 'param3-3-2', chlNode: []},
                        {node: 'param3-3-3', chlNode: []},
                        {node: 'param3-3-4', chlNode: []},
                        {node: 'param3-3-5', chlNode: []}
                    ]},
                    {node: 'param3-4', chlNode: [
                        {node: 'param3-4-1', chlNode: []},
                        {node: 'param3-4-2', chlNode: []},
                        {node: 'param3-4-3', chlNode: []},
                        {node: 'param3-4-4', chlNode: []},
                        {node: 'param3-4-5', chlNode: []}
                    ]},
                    {node: 'param3-5', chlNode: [
                        {node: 'param3-5-1', chlNode: []},
                        {node: 'param3-5-2', chlNode: []},
                        {node: 'param3-5-3', chlNode: []},
                        {node: 'param3-5-4', chlNode: []},
                        {node: 'param3-5-5', chlNode: []}
                    ]}
                ]
            };
        }

        function apiGetParam4() {
            return {
                node: 'param4', chlNode: [
                    {node: 'param4-1', chlNode: [
                        {node: 'param4-1-1', chlNode: []},
                        {node: 'param4-1-2', chlNode: []},
                        {node: 'param4-1-3', chlNode: []},
                        {node: 'param4-1-4', chlNode: []},
                        {node: 'param4-1-5', chlNode: []}
                    ]},
                    {node: 'param4-2', chlNode: [
                        {node: 'param4-2-1', chlNode: []},
                        {node: 'param4-2-2', chlNode: []},
                        {node: 'param4-2-3', chlNode: []},
                        {node: 'param4-2-4', chlNode: []},
                        {node: 'param4-2-5', chlNode: []}
                    ]},
                    {node: 'param4-3', chlNode: [
                        {node: 'param4-3-1', chlNode: []},
                        {node: 'param4-3-2', chlNode: []},
                        {node: 'param4-3-3', chlNode: []},
                        {node: 'param4-3-4', chlNode: []},
                        {node: 'param4-3-5', chlNode: []}
                    ]},
                    {node: 'param4-4', chlNode: [
                        {node: 'param4-4-1', chlNode: []},
                        {node: 'param4-4-2', chlNode: []},
                        {node: 'param4-4-3', chlNode: []},
                        {node: 'param4-4-4', chlNode: []},
                        {node: 'param4-4-5', chlNode: []}
                    ]},
                    {node: 'param4-5', chlNode: [
                        {node: 'param4-5-1', chlNode: []},
                        {node: 'param4-5-2', chlNode: []},
                        {node: 'param4-5-3', chlNode: []},
                        {node: 'param4-5-4', chlNode: []},
                        {node: 'param4-5-5', chlNode: []}
                    ]}
                ]
            };
        }
    }
})();