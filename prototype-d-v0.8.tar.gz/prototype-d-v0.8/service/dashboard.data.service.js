(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .factory('DashboardDataService', DashboardDataService);


    DashboardDataService.$inject = ['$http'];

    function DashboardDataService($http) {

        var debugAPI = {
            getNeAndResource: { randomRange: 3 },
            getDashboardConfig: { randomRange: 1 },
            getParamA: { randomRange: 1 },
            getParamB: { randomRange: 1 },
            getParamC: { randomRange: 1 },
            getParamD: { randomRange: 1 }
        };

        return {
            apiGet: apiGet,
            apiPost: apiPost
        };

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function apiGet(reqType, params) {
            var httpObj = setParam(params);
            httpObj.method = 'GET';
            httpObj.params.reqType = reqType;

            if (debugAPI[reqType]) {
                httpObj.url = 'dummyAPI/' + reqType + getRandomFromRange(debugAPI[reqType].randomRange) + '.json';
            }
            return $http(httpObj);
        }

        function apiPost(reqType, params, postData) {
            var httpObj = setParam(params);
            httpObj.method = 'POST';
            httpObj.params.reqType = reqType;
            httpObj.data = postData;
            
            if (debugAPI.indexOf(reqType) > -1) {
                // console.log('DEBUG API POST: ' + reqType);
                httpObj.url = 'dummyAPI/' + reqType + '.json';
            }
            return $http(httpObj);
        }

        function setParam(params) {
            var tempObj = {
                url: '/api',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                params: {
                    userName: 'Eddie',
                    userId: 1,
                    sessionId: 'lalilulelo'
                }
            };
            for (var k in params) {
                if (params.hasOwnProperty(k)) {
                    tempObj.params[k] = params[k];
                }
            }
            return tempObj;
        }

        function getRandomFromRange(range) {
            return Math.floor(Math.random() * range) + 1;
        }
    }
})();