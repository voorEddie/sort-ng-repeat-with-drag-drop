(function () {
    'use strict';

    angular
        .module('app')
        .config(routeConfig);

    function routeConfig($routeProvider) {
        $routeProvider
            .when('/dashboard', {
                templateUrl: 'module/dashboard/dashboard.html',
                controller: 'DashboardController',
                controllerAs: 'dashboardVm'
            })
            .otherwise({redirectTo: '/dashboard'});
    }

})();