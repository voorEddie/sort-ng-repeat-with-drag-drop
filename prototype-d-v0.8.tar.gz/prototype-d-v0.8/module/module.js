(function() {
    'use strict';

    angular
        .module('app', [
            // custom module
            'app.dashboard',
            'app.dashboardConfig',
            'app.dashboardAlertModal',
            'app.dashboardItemEditor',

            // third party module
            'ngRoute',
            'ngAnimate',
            'ui.bootstrap'
        ])

})();