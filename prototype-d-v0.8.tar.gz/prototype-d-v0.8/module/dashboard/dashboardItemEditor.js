(function () {
    'use strict';

    angular
        .module('app.dashboardItemEditor', [])
        .controller('DashboardItemEditorController', DashboardItemEditorController);

    DashboardItemEditorController.$inject = ['$timeout', '$uibModalInstance', 'outerVm', 'action', 'DashboardService', 'DashboardDataService'];

    function DashboardItemEditorController($timeout, $uibModalInstance, outerVm, action, DashboardService, DashboardDataService) {
        var vm = this;
        
        vm.periodOptions = DashboardService.getPeriodOptions();
        vm.actionType = action.type;
        vm.title = action.itemConfig ? action.itemConfig.title : '';
        vm.period = action.itemConfig ? vm.periodOptions[DashboardService.findObjByAttrInObjAry(vm.periodOptions, 'value', action.itemConfig.period)] : vm.periodOptions[0];
        vm.visible = action.itemConfig ? action.itemConfig.visible : true;
        vm.trees = {
            tree1: { node: 'param1' },
            tree2: { node: 'param2', previousTreeName: 'param1' },
            tree3: { node: 'param3', previousTreeName: 'param2' },
            tree4: { node: 'param4', previousTreeName: 'param3' }
        };
        vm.save = save;
        vm.cancel = cancel;

        init();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function init() {
            getTree1();
        }

        function getTree1() {
            return DashboardDataService.apiGet('getParamA', {})
                .then(function (success) {
                    vm.trees.tree1 = success.data;

                    vm.trees.tree1 = {};
                    vm.trees.tree1.node = 'param1';
                    vm.trees.tree1.chlNode = [];
                    for (var i = 0; i < 100; i++) {
                        var temp = {};
                        temp.node = 'param' + i;
                        temp.chlNode = [];
                        for (var j = 0; j < 100; j++) {
                            var temp1 = {};
                            temp1.node = 'param' + i + '-' + j;
                            temp1.chlNode = [];
                            temp.chlNode.push(temp1);
                        }
                        vm.trees.tree1.chlNode.push(temp);
                    }

                    // return selectLeaf(action, vm.trees.tree1, 1);
                }, function (failed) {
                    console.info(failed.status + '-' + failed.statusText);
                });
        }

        function selectLeaf(action, tree) {
            if (action.type !== "edit") {
                return false;
            } else {
                // console.info(action);
                // console.info(tree);
                var targetNode = action.itemConfig.params[tree.node];
                targetNode.forEach(function (node) {
                    DashboardService.selectTreeNode(node, tree);
                });
            }
        }

        function save() {
            /**
             * send delete dashboard item API
             * If request success, 1. close this modal; 2. config modal; 3. update item list;
             * If request failed, display error message
             * The following code demonstrates request success
             *
             * using $timeout to emulate wait for response
             */
            vm.error = '';
            vm.loading = true;
            $timeout(function () {
                vm.loading = false;
                actionSuccess(DashboardService.capitalize(vm.actionType));
                /**
                 * comment out actionSuccess() and uncomment actionFailed() to mock a request failed
                 */
                // actionFailed(DashboardService.capitalize(vm.actionType));
            }, 500);
        }

        function cancel() {
            $uibModalInstance.dismiss('cancel');
        }
        
        function actionSuccess(actionType) {
            vm.error = '';
            vm.success = actionType + ' item success!';
            $timeout(function () {
                $uibModalInstance.close('confirm');
                // outerVm.updateItem(tempDelItem);
            }, 1500);
        }
        
        function actionFailed(actionType) {
            vm.error = actionType + ' item failed!';
        }

    }
})();