(function () {
    'use strict';

    angular
        .module('app.dashboardItemEditor', [])
        .controller('DashboardItemEditorController', DashboardItemEditorController);

    DashboardItemEditorController.$inject = ['$timeout', '$uibModalInstance', 'outerVm', 'action', 'DashboardService', 'DummyDataService'];

    function DashboardItemEditorController($timeout, $uibModalInstance, outerVm, action, DashboardService, DummyDataService) {
        var vm = this;

        vm.periodOptions = DashboardService.getPeriodOptions();
        vm.actionType = action.type;
        vm.title = action.itemParams ? action.itemParams.title : '';
        vm.period = action.itemParams ? vm.periodOptions[DashboardService.findObjByAttrInObjAry(vm.periodOptions, 'value', action.itemParams.period)] : vm.periodOptions[0];
        vm.visible = action.itemParams ? action.itemParams.visible : true;
        vm.confirm = confirm;
        vm.cancel = cancel;

        init();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function init() {
            // request 4 trees data
            var tree1 = DummyDataService.apiGetParam1(),
                tree2 = DummyDataService.apiGetParam2(),
                tree3 = DummyDataService.apiGetParam3(),
                tree4 = DummyDataService.apiGetParam4();
            
            tree2.hide = true;
            tree3.hide = true;
            tree4.hide = true;
            tree2.previousTreeName = tree1.node;
            tree3.previousTreeName = tree2.node;
            tree4.previousTreeName = tree3.node;

            vm.param1Tree = tree1;
            vm.param2Tree = tree2;
            vm.param3Tree = tree3;
            vm.param4Tree = tree4;
        }

        function confirm() {
            /**
             * send delete dashboard item API
             * If request success, 1. close this modal; 2. config modal; 3. update item list;
             * If request failed, display error message
             * The following code demonstrates request success
             *
             * using $timeout to emulate wait for response
             */
            vm.error = '';
            vm.loading = true;
            $timeout(function () {
                vm.loading = false;
                delSuccess();
                /**
                 * comment out delSuccess() and uncomment delFailed() to mock a request failed
                 */
                // delFailed();
            }, 500);
        }

        function cancel() {
            $uibModalInstance.dismiss('cancel');
        }
        
        function delSuccess() {
            vm.error = '';
            vm.success = 'Delete success!';
            $timeout(function () {
                $uibModalInstance.close('confirm');
                outerVm.updateItem(tempDelItem);
            }, 1500);
        }
        
        function delFailed() {
            vm.error = 'Delete failed!';
        }

    }
})();