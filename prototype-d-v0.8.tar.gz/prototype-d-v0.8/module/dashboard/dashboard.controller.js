(function () {
    'use strict';

    angular
        .module('app.dashboard', [])
        .controller('DashboardController', DashboardController);

    DashboardController.$inject = ['$interval', '$scope', '$uibModal', 'DashboardService', 'DashboardDataService'];

    function DashboardController($interval, $scope, $uibModal, DashboardService, DashboardDataService) {
        var dashboardVm = this,
            neAndResourceInterval;
        
        dashboardVm.changeLayout = changeLayout;
        dashboardVm.openConfigModal = openConfigModal;
        dashboardVm.modifyItem = modifyItem;
        dashboardVm.addItem = addItem;
        dashboardVm.editItem = editItem;
        $scope.$on('flexSort', flexSort);

        init();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function openConfigModal(size) {
            $uibModal.open({
                animation: true,
                templateUrl: '/module/dashboard/dashboardConfig.html',
                controller: 'DashboardConfigController',
                controllerAs: 'vm',
                size: size,
                windowClass: 'dashboard-modal dashboard-config',
                backdrop: 'static',
                resolve: {
                    outerVm: function () {
                        return dashboardVm;
                    }
                }
            });
        }

        function changeLayout(layoutType, bypass) {
            if (bypass || layoutType !== dashboardVm.config.layoutMode) {
                dashboardVm.config.layoutMode = layoutType;
                $scope.$broadcast('dashboardLayoutChange', layoutType);
            }
        }
        
        function modifyItem(operationType, data) {
            if (operationType === 'delete') {
                data.forEach(function (item) {
                    var deleteIndex = DashboardService.findObjByAttrInObjAry(dashboardVm.config.item, 'id', item.id),
                        deleteOrder = dashboardVm.config.item[deleteIndex].order,
                        itemLength = dashboardVm.config.item.length;
                    for (var i = deleteOrder + 1; i < itemLength; i++) {
                        dashboardVm.config.item[DashboardService.findObjByAttrInObjAry(dashboardVm.config.item, 'order', i)].order -= 1;
                    }
                    dashboardVm.config.item.splice(deleteIndex, 1);
                    changeLayout(dashboardVm.config.layoutMode, 'bypass');
                });
            } else if (operationType === 'add') {

            }
        }

        function addItem() {
            $uibModal.open({
                animation: true,
                templateUrl: '/module/dashboard/dashboardItemEditor.html',
                controller: 'DashboardItemEditorController',
                controllerAs: 'vm',
                windowClass: 'dashboard-modal editor',
                backdrop: 'static',
                resolve: {
                    outerVm: function () {
                        return dashboardVm;
                    },
                    action: function () {
                        return {
                            type: 'add'
                        }
                    }
                }
            });
        }

        function editItem(index) {
            $uibModal.open({
                animation: true,
                templateUrl: '/module/dashboard/dashboardItemEditor.html',
                controller: 'DashboardItemEditorController',
                controllerAs: 'vm',
                windowClass: 'dashboard-modal editor',
                backdrop: 'static',
                resolve: {
                    outerVm: function () {
                        return dashboardVm;
                    },
                    action: function () {
                        return {
                            type: 'edit',
                            itemConfig: dashboardVm.config.item[index]
                        }
                    }
                }
            });
        }

        function init() {
            neAndResourceInterval = updateNeAndResourceWithInterval(2000);
            DashboardDataService.apiGet('getDashboardConfig', {dummyParam: 'dummyParam'})
                .then(function (success) {
                    dashboardVm.config = success.data;
                    $scope.$broadcast('dashboardConfigLoad', dashboardVm.config);
                }, function (failed) {
                    console.info(failed.status + '-' + failed.statusText);
                });
        }

        function updateNeAndResourceWithInterval(interval) {
            return $interval(function () {
                DashboardDataService.apiGet('getNeAndResource', {dummyParam: 'dummyParam'})
                    .then(function (success) {
                        dashboardVm.neAndResource = success.data;
                    }, function (failed) {
                        console.info(failed.status + '-' + failed.statusText);
                    });
            }, interval);
        }

        function flexSort(event, eventData) {
            var dragOrder = parseInt(eventData.dragOrder),
                targetOrder = parseInt(eventData.targetOrder),
                insertMethod = eventData.insertMethod,
                dragged = getItemByOrder(dragOrder);
            if (dragOrder > targetOrder) {
                if (insertMethod === 'before') {
                    // from cached targetOrder to dragOrder - 1, each order should +1
                    sortItems(targetOrder, dragOrder - 1, 1);
                    // dragOrder should change to cached targetOrder
                    dragged.item.order = targetOrder;
                } else {
                    // from cached targetOrder + 1 to dragOrder - 1, each order should +1
                    sortItems(targetOrder + 1, dragOrder - 1, 1);
                    // dragOrder should change to cached targetOrder + 1
                    dragged.item.order = targetOrder + 1;
                }
            } else {
                if (insertMethod === 'before') {
                    // from dragOrder + 1 to cached targetOrder - 1, each order should -1
                    sortItems(dragOrder + 1, targetOrder - 1, -1);
                    // dragOrder should change to cached targetOrder - 1
                    dragged.item.order = targetOrder - 1;
                } else {
                    // from dragOrder + 1 to cached targetOrder, each order should -1
                    sortItems(dragOrder + 1, targetOrder, -1);
                    // dragOrder should change to cached targetOrder
                    dragged.item.order = targetOrder;
                }
            }
            if (!$scope.$$phase) {
                $scope.$apply();
            }
            $scope.$broadcast('afterFlexSort', true);
        }

        function getItemByOrder(order) {
            for (var i = 0, l = dashboardVm.config.item.length; i < l; i++) {
                if (dashboardVm.config.item[i].order === parseInt(order)) {
                    return {item: dashboardVm.config.item[i], index: i}
                }
            }
        }

        function sortItems(start, end, modifier) {
            var itemAry = [];
            for (var i = start; i <= end; i++) {
                itemAry.push(getItemByOrder(i));
            }
            itemAry.forEach(function (each) {
                each.item.order += 1 * modifier;
            });
        }
    }
})();