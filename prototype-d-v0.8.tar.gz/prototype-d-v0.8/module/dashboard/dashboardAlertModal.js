(function () {
    'use strict';

    angular
        .module('app.dashboardAlertModal', [])
        .controller('DashboardAlertModalController', DashboardAlertModalController);

    DashboardAlertModalController.$inject = ['$timeout', '$uibModalInstance', 'outerVm', 'tempDelItem'];

    function DashboardAlertModalController($timeout, $uibModalInstance, outerVm, tempDelItem) {
        var vm = this;
        
        vm.tempDelItem = tempDelItem;
        vm.confirm = confirm;
        vm.cancel = cancel;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function confirm() {
            /**
             * send delete dashboard item API
             * If request success, 1. close this modal; 2. config modal; 3. update item list;
             * If request failed, display error message
             * The following code demonstrates request success
             *
             * using $timeout to emulate wait for response
             */
            vm.error = '';
            vm.loading = true;
            $timeout(function () {
                vm.loading = false;
                delSuccess();
                /**
                 * comment out delSuccess() and uncomment delFailed() to mock a request failed
                 */
                // delFailed();
            }, 500);
        }

        function cancel() {
            $uibModalInstance.dismiss('cancel');
        }
        
        function delSuccess() {
            vm.error = '';
            vm.success = 'Delete success!';
            $timeout(function () {
                $uibModalInstance.close('confirm');
                outerVm.updateItem(tempDelItem);
            }, 1500);
        }
        
        function delFailed() {
            vm.error = 'Delete failed!';
        }

    }
})();