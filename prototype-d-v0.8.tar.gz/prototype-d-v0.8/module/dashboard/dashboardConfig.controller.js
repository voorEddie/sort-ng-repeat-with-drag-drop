(function () {
    'use strict';

    angular
        .module('app.dashboardConfig', [])
        .controller('DashboardConfigController', DashboardConfigController);

    DashboardConfigController.$inject = ['$uibModal', '$uibModalInstance', 'DashboardService', 'outerVm'];

    function DashboardConfigController($uibModal, $uibModalInstance, DashboardService, outerVm) {
        var vm = this;

        vm.items = DashboardService.cpObjAryWithTargetAttr(outerVm.config.item, ['id', 'title', 'subTitle', 'order', 'visible']);

        vm.toggleRemove = toggleRemove;
        vm.addItem = addItem;
        vm.saveConfig = saveConfig;
        vm.cancel = cancel;
        vm.updateItem = updateItem;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function toggleRemove(item) {
            item.remove = !item.remove;
        }

        function addItem() {
            return outerVm.addItem();
        }

        function saveConfig() {
            // check if there's any item needs remove and put there id into an Array
            var tempDelItem = [];
            for (var j = 0, k = vm.items.length; j < k; j++) {
                if (vm.items[j].remove === true) {
                    tempDelItem.push({
                        id: vm.items[j].id,
                        title: vm.items[j].title
                    });
                }
            }
            if (tempDelItem.length > 0) {
                $uibModal.open({
                    animation: true,
                    templateUrl: '/module/dashboard/dashboardAlertModal.html',
                    controller: 'DashboardAlertModalController',
                    controllerAs: 'vm',
                    windowClass: 'dashboard-modal dashboard-alert-modal',
                    backdrop: 'static',
                    resolve: {
                        outerVm: function () {
                            return vm;
                        },
                        tempDelItem: function () {
                            return tempDelItem;
                        }
                    }
                });
            } else {
                updateItem();
            }

        }

        function updateItem(tempDelItem) {
            // update outerVm item visibility
            for (var i = 0, l = vm.items.length; i < l; i++) {
                outerVm.config.item[i].visible = vm.items[i].visible;
            }
            if (tempDelItem) {
                outerVm.modifyItem('delete', tempDelItem);
                $uibModalInstance.close('updated item collection');
            } else {
                // update visibility by trigger outerVm.changeLayout
                outerVm.changeLayout(outerVm.config.layoutMode, 'bypass');
                $uibModalInstance.close('updated visibility');
            }
        }

        function cancel() {
            $uibModalInstance.dismiss('cancel');
        }

    }
})();