(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('flexMetro', flexMetro);

    flexMetro.$inject = ['$timeout', 'DashboardService'];

    function flexMetro($timeout, DashboardService) {
        return {
            restrict: "A",
            link: link
        };

        function link(scope, element, attribute) {
            /**
             * cssItemWidth = 370 is the block width defined in CSS
             * cssItemMargin = 15 is the block width defined in CSS
             */
            var cssItemWidth = 370,
                cssItemMargin = 15,
                itemWidth = cssItemWidth + cssItemMargin * 2,
                bigItemWidth = itemWidth * 2,
                config = scope.vm.config,
                wrapperWidth = element[0].getBoundingClientRect().width;

            flexItemMetroOffset(wrapperWidth, itemWidth, bigItemWidth, config);

            window.onresize = triggerResize;
            scope.$on('dashboardLayoutChange', function (event, eventData) {
                config.layoutMode = eventData;
                triggerResize();
            });
            scope.$on('afterFlexSort', function (event, eventData) {
                triggerResize();
            });

            function triggerResize() {
                wrapperWidth = element[0].getBoundingClientRect().width;
                flexItemMetroOffset(wrapperWidth, itemWidth, bigItemWidth, config);
            }

            function flexItemMetroOffset(wrapperWidth, itemWidth, bigItemWidth, config) {
                if (config.layoutMode === 'layout1') {
                    $timeout(function () {
                        // big block clear
                        config.item.forEach(function (item) {
                            item.isBig = false;
                        });
                        var bigBlockIndex = getVisBlockFromOrder(config.item, 0);
                        if (config.item[bigBlockIndex]) {
                            config.item[bigBlockIndex].isBig = true;
                            var itemNumber = (wrapperWidth - bigItemWidth) / itemWidth;
                            itemNumber = itemNumber >= 0 ? parseInt(itemNumber) : -1;
                            var visBlockAfterBigIndex = getVisBlockFromOrder(config.item, config.item[bigBlockIndex].order + 1);
                            if (visBlockAfterBigIndex === null) {
                                config.item[bigBlockIndex].offset = false;
                            }
                            if (itemNumber > 0 && visBlockAfterBigIndex !== null) {
                                var visBlockAfterBig = config.item[visBlockAfterBigIndex].order,
                                    secondLineOffsetItem = visBlockAfterBig;

                                for (var i = 0; i < itemNumber; i++) {
                                    var tempIndex = DashboardService.findObjByAttrInObjAry(config.item, 'order', secondLineOffsetItem),
                                        tempObj = config.item[tempIndex];
                                    if (!tempObj) {
                                        break;
                                    }
                                    if (tempObj.visible === false) {
                                        i -= 1;
                                    }
                                    secondLineOffsetItem += 1;
                                }
                                var secVisItemIndex = getVisBlockFromOrder(config.item, secondLineOffsetItem),
                                    secVisItem = config.item[secVisItemIndex];
                                if (secVisItemIndex === null) {
                                    offsetItemByOrder([
                                        visBlockAfterBig
                                    ], config.item, itemNumber);
                                } else {
                                    offsetItemByOrder([
                                        visBlockAfterBig,
                                        secVisItem.order
                                    ], config.item, itemNumber);
                                }
                            } else if (itemNumber <= 0) {
                                offsetItemByOrder([], config.item, itemNumber);
                            }
                            if (!scope.$$phase) {
                                scope.$apply();
                            }
                        }
                    }, 0);
                }
            }

            /**
             * @param order: The order of the flex items that should have offset in an Array
             * @param items: The flex items collection in an Array
             * @param itemNumber
             */
            function offsetItemByOrder(order, items, itemNumber) {
                if (order.length === 0) {
                    var bigBlockIndex = getVisBlockFromOrder(items, 0);
                    if (items[bigBlockIndex]) {
                        var visBlockAfterBig = getVisBlockFromOrder(items, items[bigBlockIndex].order + 1);
                        if (visBlockAfterBig === null) {
                            items[bigBlockIndex].offsetUp = false;
                        } else {
                            if (getVisBlockFromOrder(items, items[visBlockAfterBig].order + 1) == null) {
                                offsetUpOrder = [
                                    items[visBlockAfterBig].order
                                ];
                            } else {
                                var offsetUpOrder = [
                                    items[visBlockAfterBig].order,
                                    items[getVisBlockFromOrder(items, items[visBlockAfterBig].order + 1)].order
                                ];
                                if (itemNumber < 0) {
                                    offsetUpOrder = [
                                        items[visBlockAfterBig].order
                                    ];
                                }
                            }
                            items.forEach(function (item) {
                                item.offset = false;
                                item.offsetUp = offsetUpOrder.indexOf(item.order) > -1;
                            });
                        }
                    }
                } else {
                    items.forEach(function (item) {
                        item.offset = order.indexOf(item.order) > -1;
                        item.offsetUp = false;
                    });
                }
            }

            function getVisBlockFromOrder(objAry, startOrder) {
                var objIndex = DashboardService.findObjByAttrInObjAry(objAry, 'order', startOrder),
                    obj = objAry[objIndex];
                if (obj && obj.visible === true) {
                    return objIndex;
                } else if (obj) {
                    return getVisBlockFromOrder(objAry, startOrder + 1);
                } else {
                    return null;
                }
            }
        }
    }

})();