(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('dashboardLeftColumn', dashboardLeftColumn);

    dashboardLeftColumn.$inject = [];

    function dashboardLeftColumn() {
        return {
            scope: {},
            bindToController: {
                config: '<'
            },
            controller: angular.noop,
            controllerAs: 'vm',
            link: link,
            templateUrl: 'directive/dashboard/leftColumn.html'
        };

        function link(scope, elem, attr) {
            var vm = scope.vm;
        }
    }

})();