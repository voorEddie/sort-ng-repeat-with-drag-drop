(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('dashboardRightColumn', dashboardRightColumn);

    dashboardRightColumn.$inject = ['$uibModal'];

    function dashboardRightColumn($uibModal) {
        return {
            scope: {},
            bindToController: {
                config: '<'
            },
            controller: angular.noop,
            controllerAs: 'vm',
            link: link,
            templateUrl: 'directive/dashboard/rightColumn.html'
        };

        function link(scope, elem, attr) {
            var vm = scope.vm;

            vm.openConfig = openConfig;
            vm.addItem = addItem;
            vm.editItem = editItem;
            vm.hideItem = hideItem;
            vm.deleteItem = deleteItem;
            vm.isItemAllHidden = isItemAllHidden;
            vm.updateItem = updateItem;

            ////////////////////////////////////////////////////////////////////////////////////////////////////////////

            function addItem() {
                var parentVm = scope.$parent.dashboardVm;
                return parentVm.addItem();
            }

            function openConfig() {
                var parentVm = scope.$parent.dashboardVm;
                return parentVm.openConfigModal('lg');
            }

            function editItem(index) {
                var parentVm = scope.$parent.dashboardVm;
                return parentVm.editItem(index);
            }

            function hideItem(index) {
                var targetItem = vm.config.item[index],
                    parentVm = scope.$parent.dashboardVm;
                targetItem.visible = false;
                return parentVm.changeLayout(parentVm.config.layoutMode, 'bypass');
            }

            function deleteItem(index) {
                var targetItem = [vm.config.item[index]],
                    parentVm = scope.$parent.dashboardVm;

                $uibModal.open({
                    animation: true,
                    templateUrl: '/module/dashboard/dashboardAlertModal.html',
                    controller: 'DashboardAlertModalController',
                    controllerAs: 'vm',
                    windowClass: 'dashboard-modal dashboard-alert-modal',
                    backdrop: 'static',
                    resolve: {
                        outerVm: function () {
                            return vm;
                        },
                        tempDelItem: function () {
                            return targetItem;
                        }
                    }
                });
            }

            function updateItem(tempDelItem) {
                var parentVm = scope.$parent.dashboardVm;
                if (tempDelItem) {
                    return parentVm.modifyItem('delete', tempDelItem);
                }
            }

            function isItemAllHidden(objAry) {
                if (objAry) {
                    for (var i = 0, l = objAry.length; i < l; i++) {
                        if (objAry[i] && objAry[i].visible === true) {
                            return false;
                        }
                    }
                    return true;
                }
            }
        }
    }

})();