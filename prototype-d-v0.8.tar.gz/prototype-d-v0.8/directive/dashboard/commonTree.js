(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('commonTree', commonTree);

    function commonTree() {
        return {
            scope: {},
            bindToController: {
                config: '<'
            },
            controller: angular.noop,
            controllerAs: 'vm',
            link: link,
            templateUrl: 'directive/dashboard/commonTree.html'
        };
        
        function link(scope, elem, attr) {
            var vm = scope.vm;
        }
    }



})();