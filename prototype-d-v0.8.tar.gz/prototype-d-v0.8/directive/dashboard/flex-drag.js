(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('flexDrag', flexDrag);

    flexDrag.$inject = [];

    function flexDrag() {
        return {
            restrict: "A",
            link: link
        };

        function link(scope, element, attribute) {
            element.on('dragstart', function (event) {
                element.parent().addClass('dragging');
                event.dataTransfer.setData("text/plain", element.attr('data-order'));
            });
            element.on('dragover', function (event) {
                event.preventDefault();
                var result = processDragNDrop(element, event);
                if (result) {
                    if (result.insertMethod === 'before') {
                        element.removeClass('insert-after');
                        element.addClass('insert-before');
                    } else {
                        element.removeClass('insert-before');
                        element.addClass('insert-after');
                    }
                    
                }
            });
            element.on('dragleave', function (event) {
                event.preventDefault();
                var before = ' insert-before',
                    after = ' insert-after';
                if (event.target.className) {
                    event.target.className = event.target.className.replace(before, '');
                    event.target.className = event.target.className.replace(after, '');
                }
            });
            element.on('drop', function (event) {
                event.preventDefault();
                var result = processDragNDrop(element, event);
                if (result) {
                    var sib = element.parent().children();
                    sib.removeClass('insert-before');
                    sib.removeClass('insert-after');
                    scope.$emit('flexSort', result);
                }
            });
            element.on('dragend', function (event) {
                event.preventDefault();
                element.parent().removeClass('dragging');
            });
        }

        function processDragNDrop(element, event) {
            var dropX = event.clientX,
                dropZoneRect = element[0].getBoundingClientRect(),
                dropZoneMiddleX = dropZoneRect.left + dropZoneRect.width / 2,
                dragOrder = event.dataTransfer.getData("text"),
                targetOrder = element.attr('data-order');

            if (dragOrder !== targetOrder) {
                return {
                    dragOrder: dragOrder,
                    targetOrder: targetOrder,
                    insertMethod: dropX < dropZoneMiddleX ? 'before' : 'after'
                };
            } else {
                return false;
            }
        }
    }

})();