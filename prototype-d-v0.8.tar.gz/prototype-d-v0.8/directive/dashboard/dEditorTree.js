(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('dEditorTree', dEditorTree)
        .controller('DashboardTreeController', DashboardTreeController);

    dEditorTree.$inject = [];

    function dEditorTree() {
        return {
            scope: {},
            bindToController: {
                tree: '<',
                show: '<'
            },
            controller: DashboardTreeController,
            controllerAs: 'vm',
            templateUrl: 'directive/dashboard/dEditorTree.html'
        };
    }

    DashboardTreeController.$inject = [];

    function DashboardTreeController() {
        var vm = this;

        vm.onLeafClick = onLeafClick;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function onLeafClick(leaf) {
            var operateType = leaf.isSelect,
                allowMultiSelect = vm.tree.multiSelect;
            // console.info(operateType);
            // console.info(allowMultiSelect);
            // vm.config.selected.push(leaf);
            vm.tree.selected = [];
            vm.tree.selected.push(leaf)
        }
    }

})();