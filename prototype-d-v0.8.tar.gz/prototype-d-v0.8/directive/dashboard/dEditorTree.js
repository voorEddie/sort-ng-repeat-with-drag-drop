(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('dEditorTree', dEditorTree);

    dEditorTree.$inject = [];

    function dEditorTree() {
        return {
            scope: {},
            bindToController: {
                config: '<'
            },
            controller: angular.noop,
            controllerAs: 'vm',
            link: link,
            templateUrl: 'directive/dashboard/dEditorTree.html'
        };

        function link(scope, elem, attr) {
            var vm = scope.vm;
        }
    }

})();