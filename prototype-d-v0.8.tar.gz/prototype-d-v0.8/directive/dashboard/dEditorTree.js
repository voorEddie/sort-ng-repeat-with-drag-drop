(function () {
    'use strict';

    angular
        .module('app.dashboard')
        .directive('dEditorTree', dEditorTree)
        .controller('DashboardTreeController', DashboardTreeController);

    dEditorTree.$inject = [];

    function dEditorTree() {
        return {
            scope: {},
            bindToController: {
                tree: '<',
                show: '<'
            },
            controller: DashboardTreeController,
            controllerAs: 'vm',
            templateUrl: 'directive/dashboard/dEditorTree.html'
        };
    }

    DashboardTreeController.$inject = ['DashboardService'];

    function DashboardTreeController(DashboardService) {
        var vm = this;
        var cachedFullTree = JSON.parse(JSON.stringify(vm.tree));

        vm.onLeafClick = onLeafClick;
        vm.filterTree = filterTree;

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        function filterTree(value) {
            var fullTree = JSON.parse(JSON.stringify(cachedFullTree));
            
        }



        function onLeafClick(leaf) {
            var operateType = leaf.isSelect,
                allowMultiSelect = vm.tree.multiSelect;
            // console.info(operateType);
            // console.info(allowMultiSelect);
            // vm.config.selected.push(leaf);
            vm.tree.selected = [];
            vm.tree.selected.push(leaf)
        }
    }

})();